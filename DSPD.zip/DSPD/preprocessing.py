from sklearn.preprocessing import StandardScaler
import pandas as pd


class SegmentStandardScaler(object):

    def __init__(self, segments):
        """
        Standard Scaler for a table with known values. 
        
        Args:
        :param segments: array-like
            List of segment names in the table.
        """
        self.segments = segments
        self.scalers = {}

    def fit(self, df):
        """
        Args:
        :param df: pandas.DataFrame
            Table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        :return:
            self
        """
        
        for aseg in self.segments:
            df_seg = df[df['segment'] == aseg]
            scaler_seg = StandardScaler()
            scaler_seg.fit(df_seg[['target']].values)
            self.scalers[aseg] = scaler_seg

        return self

    def transform(self, df):
        """
        Args:
        :param df: pandas.DataFrame
            Table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        :return:
        df: pandas.DataFrame
            Scaled table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        """

        df_scaled = []
        for aseg in self.segments:
            df_seg = df[df['segment'] == aseg]
            scaler_seg = self.scalers[aseg]
            target_seg = scaler_seg.transform(df_seg[['target']].values)
            df_seg = df_seg[['timestamp', 'segment']]
            df_seg['target'] = target_seg
            df_scaled.append(df_seg)
        df_scaled = pd.concat(df_scaled, axis=0)
        df_scaled = pd.merge(df[['timestamp', 'segment']], df_scaled, 'left', on=['timestamp', 'segment'])

        return df_scaled

    def fit_transform(self, df):
        """
        Args:
        :param df: pandas.DataFrame
            Table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        :return:
        df: pandas.DataFrame
            Scaled table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        """
        return self.fit(df).transform(df)

    def inverse_transform(self, df):
        """
        Args:
        :param df: pandas.DataFrame
            Table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        :return:
        df: pandas.DataFrame
            Scaled table with known values.
            Required columns: 'timestamp', 'target', 'segment'.
        """

        df_scaled = []
        for aseg in self.segments:
            df_seg = df[df['segment'] == aseg]
            scaler_seg = self.scalers[aseg]
            target_seg = scaler_seg.inverse_transform(df_seg[['target']].values)
            df_seg = df_seg[['timestamp', 'segment']]
            df_seg['target'] = target_seg
            df_scaled.append(df_seg)
        df_scaled = pd.concat(df_scaled, axis=0)
        df_scaled = pd.merge(df[['timestamp', 'segment']], df_scaled, 'left', on=['timestamp', 'segment'])

        return df_scaled