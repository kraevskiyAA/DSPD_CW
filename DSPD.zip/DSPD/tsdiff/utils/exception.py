class NotSupportedModelNoiseCombination(Exception):
    pass
